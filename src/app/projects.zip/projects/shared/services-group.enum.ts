export enum ServicesGroup {
    Low,
    Medium,
    High
}