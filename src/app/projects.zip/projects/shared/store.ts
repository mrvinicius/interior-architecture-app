export class Store {
    id?: string;
    name: string;
    email?: string;
    tel?: string;
}