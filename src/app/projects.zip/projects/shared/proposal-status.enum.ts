export enum ProposalStatus {
    Approved,
    Disabled,
    NotSent,
    Waiting,
    Deprecated
}
