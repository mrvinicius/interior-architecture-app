export enum ProjectStatus {
    Approved,
    Disabled,
    NotSent,
    Waiting
}
