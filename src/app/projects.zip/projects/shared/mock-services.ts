// import { Service } from '../shared/service';
// import { ServiceType } from './service-type';

// export const services: Service[] = [
//     {
//         id: 1,
//         description: 'descrição deste serviço',
//         serviceType: {id: 'ba469642-6d55-44a2-8bf9-11207435da17', type: 'Exec', typeDescription: 'Executivo'}
//     },
//     {
//         id: 2,
//         description: 'uma descrição qualquer',
//         serviceType: {id: 'e0f3481a-e605-4e7b-a4d0-e3f24fbde240', type: 'EPr', typeDescription: 'Estudos preliminares'}
//     },
//     {
//         id: 3,
//         description: 'descrição definida pelo funcionario',
//         serviceType: {id: 'fde1b303-22a2-41c0-a1e6-6bf5056873a8', type: 'Acomp', typeDescription: 'Acomapanhamento'}
//     },

// ];