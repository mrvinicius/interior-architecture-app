export enum Service {
    'Layout de distribuição de móveis + Detalhamento de poucos móveis',
    'Escolha de tecidos, móveis, revestimentos e luminárias',
    
    'Projeto de Arquitetura de Interiores + Detalhamento de mobiliário',

    'Escolha de acabamentos',
    'Distribuição e localização de pontos elétricos e hidráulicos',
    'Detalhamento de banheiros e cozinhas',
    'Detalhamento de forro',
}
