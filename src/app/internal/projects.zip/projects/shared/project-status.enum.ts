export enum ProjectStatus {
    Approved,
    Waiting,
    Disabled
}
