export class Client {
    id: number;
    name: string;
    email: string;
    cpf: string;
}