import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <h1>Clientes</h1>
    <!--<router-outlet></router-outlet>-->
  `
})
export class ClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
