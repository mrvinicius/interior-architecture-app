// import { Professional } from './../../core/professional';
// import { BillingInfo } from './billing-info';

export interface CreditCardInfo {
    // professional: Professional;
    number: string;
    expirationMonth: number;
    expirationYear: number;
    cvc: number;

}
